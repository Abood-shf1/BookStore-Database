# Steps for Dockerizing the Python Application

## running locally for testing 

1. change directory to python-app/app
    ```
    cd app
    ```
2. Build the Docker image with the following command:
   ```
   docker build -t bookstore-app .
   ```
3. Run the Docker container with the following command:
   ```
   docker run --detach --publish 5000:5000 bookstore-app
   ```
After running the command, you can access the application at [http://localhost:5000/](http://localhost:5000/)

## uploading to azure container registry

1. Create a container registry on azure portal named `ain3003bookstoreContaineRregistry`
2. from settings, then access keys, enable admin user and obtain the username and password
username: ain3003bookstoreContaineRregistry
password: UoUoMH0dMHu8omByWXbSXxBkACOVeuheClkK2KB1QL+ACRBkp4bl
3. login to the container registry using the following command:
    ```
    docker login ain3003bookstoreContaineRregistry.azurecr.io -u ain3003bookstoreContaineRregistry -p UoUoMH0dMHu8omByWXbSXxBkACOVeuheClkK2KB1QL+ACRBkp4bl
    ```
4. build the docker image with the following command:
    ```
    docker build -t ain3003bookstoreContaineRregistry.azurecr.io/bookstore-app:latest .
    ```
5. push the docker image to the container registry with the following command:
    ```
    docker image push ain3003bookstoreContaineRregistry.azurecr.io/bookstore-app:latest
    ```



# Steps for deploying to AKS (Azure Kubernetes Service)

1. Create a new AKS cluster on azure portal named `ain3003bookstoreAKS`
node: Standard B2s
node count: 1
pod count: 30

2. attach the AKS cluster to the container registry
from overview, click on `attach`, then select the container registry `ain3003bookstoreContaineRregistry`

3. make sure az cli is installed and logged in
```
az login 
```
4. login to the AKS cluster using the following command:
    ```
    az aks get-credentials --resource-group CosmosDBResourceGroup --name ain3003bookstoreAKS
    ```
5. enable anonymous pull for the container registry
    ```
    az acr update --name ain3003bookstoreContaineRregistry --anonymous-pull-enabled true
    ```

6. apply the yaml file
    ```
    kubectl apply -f kubernetes-configuration/deployment.yaml
    kubectl apply -f kubernetes-configuration/mongodb-deployment.yaml
    kubectl apply -f kubernetes-configuration/mongodb-service.yaml
    kubectl apply -f kubernetes-configuration/service.yaml
    kubectl apply -f kubernetes-configuration/policy.yaml
    ```

7. check if the deployment is successful
    ```bash
    kubectl get deployments
    ```
    ```
    NAME                         READY   UP-TO-DATE   AVAILABLE   AGE
    ain3003bookstoredeployment   2/2     2            2           31m
    mongodb                      1/1     1            1           70m
    ```

8. access the application using the external ip of the service
    ```bash
    kubectl get services
    ```
    ```
    NAME                TYPE           CLUSTER-IP     EXTERNAL-IP     PORT(S)          AGE
    bookstore-service   LoadBalancer   10.0.92.166    74.248.80.212   5000:31397/TCP   28m
    kubernetes          ClusterIP      10.0.0.1       <none>          443/TCP          140m
    mongodb-service     ClusterIP      10.0.120.108   <none>          27017/TCP        71m
    ```

9. access the application using the external ip of the service
    ```
    http://74.248.80.212:5000/
    ```

