from pymongo import MongoClient
from bson.objectid import ObjectId
from flask import Flask, render_template, request, redirect, url_for

app = Flask(__name__)

# Cosmos DB configuration
cosmosdb_username = "bookstore-cosmosdb2"
cosmosdb_password = "H9ayPYUr2P22GuCWlEtVReoOvapaV9ZmUs7EaVT1OdZdAhjZH9D0Anoknu2MsKNJU6cGtJqaw5qGACDbGZcZHg=="
cosmosdb_database = "BOOKSTORE"
cosmosdb_collection = "mycollection"

# Azure Cosmos DB MongoDB instance connection details
cosmosdb_uri = f"mongodb://{cosmosdb_username}:{cosmosdb_password}@{cosmosdb_username}.mongo.cosmos.azure.com:10255/?ssl=true&replicaSet=globaldb&retryWrites=false"
#cosmosdb_uri = "mongodb://localhost:27017/"

# Create MongoDB client
client = MongoClient(cosmosdb_uri)

db = client[cosmosdb_database]
#db = client['ain3003']

# Access the specific collection within the database
collection = db[cosmosdb_collection]
#collection = db['bookstore']

# Main page route - List all books
@app.route('/', methods=['GET'])
@app.route('/books', methods=['GET'])
def get_books():
    books = list(collection.find({}, {'title': 1, 'author': 1})) # removed coverPhoto from the query as it is not in the database
    return render_template('index.html', books=books)

# Book detail page route
@app.route('/book/<book_id>', methods=['GET'])
def book_detail(book_id):
    book = collection.find_one({'_id': ObjectId(book_id)})
    return render_template('book_detail.html', book=book)

# Add a new document form
@app.route('/books/add', methods=['GET'])
def add_book_form():
    return render_template('add_book.html')

# POST - Add a new document
@app.route('/books', methods=['POST'])
def create_book():
    form_data = request.form.to_dict()
    
    # Create book document structure
    book_document = {
        'author': {
            'firstName': form_data.pop('authorFirstName', ''),
            'lastName': form_data.pop('authorLastName', '')
        },
        'publisher': {
            'name': form_data.pop('publisherName', '')
        }
    }
    # Add remaining form fields to book document
    book_document.update(form_data)
    
    collection.insert_one(book_document)
    return redirect(url_for('get_books'))  # Redirect back to the book list


# GET - Update a document form by ID
@app.route('/books/edit/<string:id>', methods=['GET'])
def update_book_form(id):
    existing_book = collection.find_one({'_id': ObjectId(id)})
    return render_template('edit_book.html', book=existing_book)

# POST - Update a document by ID
@app.route('/books/edit/<string:id>', methods=['POST'])
def save_book_changes(id):
    form_data = request.form.to_dict()
    document_id = ObjectId(id)
    
    updated_data = {
        'author': {
            'firstName': form_data.pop('authorFirstName', ''),
            'lastName': form_data.pop('authorLastName', '')
        },
        'publisher': {
            'name': form_data.pop('publisherName', '')
        }
    }
    updated_data.update(form_data)
    
    collection.update_one(
        {'_id': document_id}, 
        {'$set': updated_data}
    )
    return redirect(url_for('get_books'))  # Redirect back to the book list


# GET - Delete confirmation for a document by ID
@app.route('/books/delete/<string:id>', methods=['GET'])
def delete_book_confirm(id):
    target_book = collection.find_one({'_id': ObjectId(id)})
    return render_template('delete_confirm.html', book=target_book)

# POST - Delete a document by ID
@app.route('/books/delete/<string:id>', methods=['POST'])
def delete_book(id):
    document_id = ObjectId(id)  # Convert received id into ObjectId
    collection.delete_one({'_id': document_id})  # Delete the document
    return redirect(url_for('get_books'))

if __name__ == '__main__':
    app.run(debug=True, port=5000)

